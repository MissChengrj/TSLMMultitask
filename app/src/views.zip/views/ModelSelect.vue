<template>
  <div class="model-select-page">
    <el-card class="model-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <h2 class="text-xl font-bold m-0">模型选择与参数配置</h2>
          <el-button text @click="router.push('/tasks')">返回任务选择</el-button>
        </div>
      </template>

      <div v-if="store.hasData">
        <el-alert :title="`当前任务目标: ${getTaskName(store.currentTask)}`" type="success" show-icon :closable="false" style="margin-bottom: 20px;" />

        <h3>数据与统计配置</h3>
        <el-form label-width="160px" class="param-form mt-4" style="background-color: #f8fafc; padding: 20px; border-radius: 8px; border: 1px dashed #cbd5e1; margin-bottom: 20px;">
          
          <!-- ================= 新增：数据源格式动态切换 ================= -->
          <el-form-item label="数据源格式" required>
            <div>
              <el-radio-group v-model="store.dataType" @change="reparseData">
                <el-radio value="baseline" border>标准基线数据</el-radio>
                <el-radio value="qar" border>航空 QAR 数据</el-radio>
              </el-radio-group>
              <div style="font-size: 12px; color: #64748b; line-height: 1.5; margin-top: 8px;">
                <span v-if="store.dataType === 'baseline'">当前解析模式：<b>基线数据</b>。系统会自动寻找 Flight DateTime 等标识，并从第 5 列起提取时序特征。</span>
                <span v-else>当前解析模式：<b>QAR 数据</b>。系统会自动寻找 FRAME_COUNTER 等标识，并从第 4 列起提取时序特征。</span>
                <br/><span style="color: #f59e0b;">* 若下方未出现您期望的特征列，请切换此选项，系统将立即重新提取文件。</span>
              </div>
            </div>
          </el-form-item>
          <!-- ========================================================== -->

          <el-form-item label="目标分析参数" required>
            <el-select v-model="targetVariables" :multiple="isMultiTarget" :placeholder="isMultiTarget ? '请选择多个参数' : '请选择一个核心参数'" style="width: 100%; max-width: 600px;">
              <el-option v-for="col in store.selectedColumns" :key="col" :label="col" :value="col" />
            </el-select>
          </el-form-item>
          
          <el-form-item label="相关协变量" v-if="store.currentTask === 'covariate_forecast'" required>
            <el-select v-model="covariateVariables" multiple placeholder="请选择影响目标的协变量" style="width: 100%; max-width: 600px;">
              <el-option v-for="col in store.selectedColumns" :key="col" :label="col" :value="col" />
            </el-select>
          </el-form-item>

          <el-form-item label="分析数据范围" v-if="['data_repair', 'anomaly_detection'].includes(store.currentTask)">
            <div style="width: 100%; max-width: 600px;">
              <el-slider v-model="dataRange" range :max="store.currentFile.rows" style="margin-left: 10px; margin-right: 10px;" />
              <div class="el-upload__tip" style="color: #64748b; line-height: 1.4;">
                拖动滑块截取指定的行数区间进行处理。当前截取范围：<strong style="color: #3b82f6;">第 {{ dataRange[0] }} 行</strong> 至 <strong style="color: #3b82f6;">第 {{ dataRange[1] }} 行</strong>，总数据量：{{ store.currentFile.rows }} 行。
              </div>
            </div>
          </el-form-item>

          <el-form-item label="置信区间 (CI)" v-if="['univariate_forecast', 'multivariate_forecast', 'covariate_forecast'].includes(store.currentTask)">
            <el-select v-model="confidenceInterval" style="width: 100%; max-width: 200px;">
              <el-option label="80%" :value="0.80" /><el-option label="90%" :value="0.90" /><el-option label="95%" :value="0.95" />
            </el-select>
          </el-form-item>

          <el-form-item label="可视化选项" v-if="store.currentTask !== 'data_repair'">
            <el-switch v-model="store.showHistoricalData" active-text="在结果图表中展示历史数据" />
          </el-form-item>
        </el-form>

        <el-divider />

        <h3>可用模型</h3>
        <div class="model-grid">
          <div v-for="model in filteredModels" :key="model.name" class="model-card-item" :class="{ 'is-active': store.selectedModel === model.name }" @click="store.selectedModel = model.name">
            <div class="model-info">
              <h4>{{ model.name }}</h4><p>{{ model.description }}</p>
            </div>
            <div class="check-mark" v-if="store.selectedModel === model.name">✓</div>
          </div>
        </div>

        <el-divider v-if="store.selectedModel" />

        <div v-if="displayedParameters.length > 0" class="param-section fade-in">
          <h3>模型超参数配置</h3>
          <el-form label-width="160px" class="param-form mt-4">
            <el-form-item v-for="param in displayedParameters" :key="param.name" :label="param.description">
              <div v-if="param.param_type === 'integer'" style="display: flex; align-items: center; gap: 10px;">
                <el-input-number :model-value="Number(param.default)" @update:model-value="(val) => param.default = String(val)" :min="1" :max="param.name === 'context_length' ? Math.min(store.currentFile.rows, 2048) : 10000" />
                <el-button 
                  v-if="param.name === 'context_length' && ['univariate_forecast', 'multivariate_forecast', 'covariate_forecast'].includes(store.currentTask)" 
                  size="small" type="primary" plain 
                  @click="param.default = String(Math.min(store.currentFile.rows, 2048))"
                >
                  一键最大 (安全视野: 2048步)
                </el-button>
              </div>
              <el-input-number v-else-if="param.param_type === 'float'" :model-value="Number(param.default)" @update:model-value="(val) => param.default = String(val)" :step="0.1" :min="0.1" :max="10.0" />
            </el-form-item>
          </el-form>
        </div>

        <div class="action-footer mt-8 flex justify-end">
          <el-button type="primary" size="large" @click="executeTask" :disabled="!store.selectedModel || store.loading" :loading="store.loading">执行计算</el-button>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watchEffect } from 'vue'
import { useDataStore } from '../stores/data'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

const store = useDataStore()
const router = useRouter()
const isMultiTarget = computed(() => store.currentTask !== 'univariate_forecast')
const targetVariables = ref<string | string[]>(isMultiTarget.value ? [] : '')
const covariateVariables = ref<string[]>([])
const confidenceInterval = ref<number>(0.90)

const dataRange = ref<[number, number]>([0, 0])
watchEffect(() => {
  if (store.currentFile && dataRange.value[1] === 0) {
    dataRange.value = [0, store.currentFile.rows]
  }
})

// ================= 新增：切换格式后重新解析文件的方法 =================
const reparseData = async () => {
  if (!store.currentFile || !store.currentFile.path) return;
  try {
    store.loading = true;
    const path = store.currentFile.path;
    const isExcel = path.toLowerCase().endsWith('.xls') || path.toLowerCase().endsWith('.xlsx');
    
    // 调用 store 中的加载方法重新解析文件
    await store.loadFileData(path, isExcel);
    
    // 清空已经选择的列，因为重新解析后列名可能变了
    targetVariables.value = isMultiTarget.value ? [] : '';
    covariateVariables.value = [];
    
    // 重置滑动条范围
    dataRange.value = [0, store.currentFile.rows];
    
    ElMessage.success("已切换数据格式，文件已重新解析！");
  } catch (err: any) {
    ElMessage.error(`重新解析失败: ${err.message || err}`);
  } finally {
    store.loading = false;
  }
}
// ======================================================================

const getTaskName = (id: string) => ({ 'data_repair': '数据修复', 'anomaly_detection': '异常检测', 'univariate_forecast': '单变量预测', 'multivariate_forecast': '多变量预测', 'covariate_forecast': '协变量预测' }[id] || id)

const filteredModels = computed(() => store.models.filter(m => m.supported_tasks.includes(getTaskName(store.currentTask))))
const selectedModelInfo = computed(() => store.models.find(m => m.name === store.selectedModel))

const displayedParameters = computed(() => {
  if (!selectedModelInfo.value) return [];
  const task = store.currentTask;
  if (task === 'data_repair') return []; 
  if (task === 'anomaly_detection') return selectedModelInfo.value.parameters.filter(p => p.name === 'anomaly_threshold');
  return selectedModelInfo.value.parameters.filter(p => p.name !== 'anomaly_threshold'); 
});

onMounted(() => { store.loadModels(); store.selectedModel = ''; })

const executeTask = async () => {
  if (!store.selectedModel) return;
  const finalTargets = isMultiTarget.value ? (targetVariables.value as string[]) : [targetVariables.value as string];
  
  if (finalTargets.length === 0 || finalTargets[0] === '') {
    ElMessage.warning("请至少选择一个目标分析参数！"); return;
  }
  
  let dStart = 0; let dEnd = store.currentFile.rows;
  if (['data_repair', 'anomaly_detection'].includes(store.currentTask)) {
      dStart = dataRange.value[0];
      dEnd = dataRange.value[1];
      if (dStart >= dEnd) {
          ElMessage.warning("请选择有效的数据提取范围！"); return;
      }
  }

  let predictionLength = 24; let anomalyThreshold = 3.0; let contextLength = 512;
  selectedModelInfo.value?.parameters.forEach(p => {
    if (p.name === 'prediction_length') predictionLength = parseInt(p.default.toString());
    if (p.name === 'anomaly_threshold') anomalyThreshold = parseFloat(p.default.toString());
    if (p.name === 'context_length') contextLength = parseInt(p.default.toString());
  });
  
  try {
    store.loading = true;
    await store.runPrediction(store.currentTask, finalTargets, covariateVariables.value, predictionLength, confidenceInterval.value, anomalyThreshold, contextLength, dStart, dEnd);
    router.push('/results'); 
  } catch (err: any) { ElMessage.error(`计算失败: ${err.message || err}`); } finally { store.loading = false; }
}
</script>

<style scoped>
.model-select-page { padding: 20px; max-width: 1000px; margin: 0 auto; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
.model-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; }
.model-card-item { position: relative; border: 2px solid #e2e8f0; border-radius: 8px; padding: 16px; cursor: pointer; background-color: #fff; transition: all 0.2s; }
.model-card-item:hover { border-color: #93c5fd; transform: translateY(-2px); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
.model-card-item.is-active { border-color: #3b82f6; background-color: #eff6ff; }
.model-info h4 { margin: 0 0 8px 0; font-size: 1.1rem; } .model-info p { margin: 0 0 12px 0; color: #64748b; font-size: 0.9rem; }
.check-mark { position: absolute; top: 12px; right: 12px; color: #3b82f6; font-weight: bold; font-size: 1.2rem; }
.fade-in { animation: fadeIn 0.3s ease-in-out; } @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
.mt-4 { margin-top: 1rem; } .mt-8 { margin-top: 2rem; } .flex { display: flex; } .justify-end { justify-content: flex-end; } .text-xl { font-size: 1.25rem; } .font-bold { font-weight: 700; } .m-0 { margin: 0; }
</style>